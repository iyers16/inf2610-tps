/*
 * Init Lab - q1.h
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#ifndef _Q1_H
#define _Q1_H

void question1();

#endif
