/*
 * Ecole Polytechnique Montreal - GIGL
 * Automne 2024
 * Challenges - part2.c
 *
 * Ajoutez vos noms, prénoms et matricules
*/
#include "challenges_part2.h"

Matrix* multiply(Matrix* A, Matrix* B) {
    
    // TODO

    return (void*)1;
}


// This main is to help you in your development. 
// Don't forget to comment it out when you run the tests.
// int main(int argc, char*argv[])
// {
   
//     return 0;
// }
